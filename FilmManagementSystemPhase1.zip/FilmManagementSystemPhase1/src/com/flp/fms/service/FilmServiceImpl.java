package com.flp.fms.service;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService{

	private IFilmDao filmDao=new FilmDaoImplForList();
	
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getcategories() {
		
		return filmDao.getCategories();
	}

	
	
	@Override
	public void addFilm(Film film) {
		
		//setting filmId to a random number
		film.setFilm_Id(generateFilmId());
		
		filmDao.addFilm(film);
		
	}
	
	
	
	//TO GENERATE A RANDOM FILM ID
	public int generateFilmId(){
		
		int filmId;
		boolean flag = false;
		
		do{
			
			//assigning a random number to the filmId
			filmId = (int)(Math.random()*1000);
			
			flag = isDuplicateFilmId(filmId);
			
		}while(flag);
		
		return filmId;
	}
	
	
	
	//CHECKING WHETHER GENERATED FILM ID ALREADY EXISTS IN THE REPOSITORY
	public boolean isDuplicateFilmId(int filmId){
		
		boolean flag =false;
		
		//retrieving all the keys in the Film Repository
		Collection<Integer> keys = filmDao.getAllFilm().keySet();
		
		Iterator<Integer> itr = keys.iterator(); 
		while(itr.hasNext()){
			
			if(itr.next() == filmId){
				
				flag = true;
				break;
			}
		}
		
		return flag;
		
	}

	@Override
	public Map<Integer, Film> getAllFilm() {
		
		return filmDao.getAllFilm();
	}

	
	//RETRIEVING FILM FROM FILM REPOSITORY USING FILM ID
	@Override
	public Film searchFilm(int filmId) {
			
		return filmDao.searchFilm(filmId);
	}
	
	//RETRIEVING FILM FROM FILM REPOSITORY USING LANGUAGE
	@Override
	public List<Film> searchFilm(Language language) {
		
		return filmDao.searchFilm(language);
	}
	
	//RETRIEVING FILM FROM FILM REPOSITORY USING FILM TITLE
	@Override
	public Film searchFilm(String title) {
		
		return filmDao.searchFilm(title);
	}
	
	
	//RETRIEVING FILM FROM FILM REPOSITORY USING FILM RATING
	@Override
	public List<Film> searchFilmByRating(int rating) {
		
		return filmDao.searchFilmByRating(rating);
	}
	
	
	//RETRIEVING FILM FROM FILM REPOSITORY USING ACTOR
	@Override
	public List<Film> searchFilm(Actor actor) {
		
		return filmDao.searchFilm(actor);
	}
	
	
	@Override
	public Film searchFilm(String title, Date releaseDate, int rating) {

		return filmDao.searchFilm(title, releaseDate, rating);
	}

	
	//REMOVING FILM USING FILM ID
	@Override
	public void removeFilm(int filmId) {
		
		filmDao.removeFilm(filmId);
	}

	//REMOVING FILM USING FILM TITLE
	@Override
	public void removeFilm(String title) {
		
		filmDao.removeFilm(title);
	}

	//REMOVING FILM USING RATING
	@Override
	public void removeFilmByRating(int rating) {
		
		filmDao.removeFilmByRating(rating);
	}

	@Override
	public void removeFilm(Actor actor) {
		
		filmDao.removeFilm(actor);
	}

	@Override
	public void updateFilm(Film film) {

		filmDao.updateFilm(film);	
	}

	
}
