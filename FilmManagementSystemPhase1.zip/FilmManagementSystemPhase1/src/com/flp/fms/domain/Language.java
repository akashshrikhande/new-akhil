package com.flp.fms.domain;

public class Language {
	
	
	//private field
private int language_Id;
private String languageName;


//No argument constructor
public Language(){
	
}


//Constructor with fields
public Language(int lanuage_Id, String languageName) {
	super();
	this.language_Id = lanuage_Id;
	this.languageName = languageName;
	
}
//Getters and setters

public int getLanguageId() {
	return language_Id;
}
public void setLanguageId(int lanuageId) {
	this.language_Id = language_Id;
}
public String getLanguageName() {
	return languageName;
}
public void setLanguageName(String languageName) {
	this.languageName = languageName;
}


//to string method
@Override
public String toString() {
	return "Language [lanuage_Id=" + language_Id + ", languageName=" + languageName + "]";
}


}
