var app=angular.module("myApp",[]);

app.controller("ctrl",function($scope,$http){
	$http.get('http://localhost:8083/Spring_Angular/emp/empContent').
	success(function(data){
		$scope.emp=data;
	});
});

app.controller("myCtrl",function($scope,$http){
	$http.get('http://localhost:8083/Spring_Angular/emp/departContent').
	success(function(data){
		$scope.depart=data;
	});
});




app.controller('RatingCtrl', function($scope) {
	
	 
    $scope.rating = 5;
    $scope.rateFunction = function(rating) {
     var rat=rating;
    	//alert('Rating selected - ' + rating);
     $scope.rat=rating;
     console.log(rating)
    };
  })
  .directive('starRating',
	function() {
		return {
			restrict : 'A',
			template : '<ul class="rating">'
					 + '	<li ng-repeat="star in stars" ng-class="star" ng-click="toggle($index)">'
					 + '\u2605'
					 + '</li>'
					 + '</ul>',
			scope : {
				ratingValue : '=',
				max : '=',
				onRatingSelected : '&'
			},
			link : function(scope, elem, attrs) {
				var updateStars = function() {
					scope.stars = [];
					for ( var i = 0; i < scope.max; i++) {
						scope.stars.push({
							filled : i < scope.ratingValue
						});
					}
				};
				
				scope.toggle = function(index) {
					scope.ratingValue = index + 1;
					scope.onRatingSelected({
						rating : index + 1
					});
				};
				
				scope.$watch('ratingValue',
					function(oldVal, newVal) {
						if (newVal) {
							updateStars();
						}
					}
				);
			}
		};
	}
);
