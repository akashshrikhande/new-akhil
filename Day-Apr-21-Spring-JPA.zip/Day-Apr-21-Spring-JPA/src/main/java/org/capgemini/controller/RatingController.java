package org.capgemini.controller;

public class RatingController {

}
