package com.flp.fms.dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

	public class ActorDaoImpl implements IActorDao {

		
	public Connection getConnection(){
			
			Connection connection=null;
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/film","root","Pass1234");
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return connection;
		}
		
		
		
		@Override
		public List<Actor> getActors() {
			
			
			Connection con=getConnection();
			List<Actor> actorList=new ArrayList<>();
			String sql="select * from actors";

			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
						
				while(rs.next()){
					Actor actors=new Actor();
					actors.setActorId((rs.getInt(1)));             
					actors.setFirstName(rs.getString(2));       
					actors.setLastName(rs.getString(3)); 
					
					actorList.add(actors);
								
				}
							
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			return actorList;
		}




}
