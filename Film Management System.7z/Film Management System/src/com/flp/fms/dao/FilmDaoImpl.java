package com.flp.fms.dao;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.mysql.jdbc.Connection;

public class FilmDaoImpl implements IFilmDao{
	
	
	public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/film","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return connection;
	}
	
	
	
	
	

	@Override
	public List<Language> getLanguages() {

		Connection con=getConnection();
		List<Language> languageList=new ArrayList<>();
		String sql="select * from languages";

		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
					
			while(rs.next()){
				
				Language languages=new Language();
				languages.setLanguageId(rs.getInt(1));
				languages.setLanguageName(rs.getString(2));
				
				languageList.add(languages);
							
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languageList;
		
	}

	@Override
	public List<Category> getCategory() {

		List<Category> categoryList=new ArrayList<>();
		Connection con=getConnection();
		String sql="select * from category";

		try {
			PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
					
			while(rs.next()){
				Category category=new Category();
				category.setCategoryId(rs.getInt(1));
				category.setCategoryName(rs.getString(2));
				
							
				categoryList.add(category);
							
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return categoryList;
	}

	@Override
	public int addFilm(Film film) {
		

	    Connection con=getConnection();
			int count=0;
			String sql="insert into film(title,description,releaseYear,originalLanguage,rentalDuration,length,replacementCost,ratings,specialFeatures,category)"
												+ "	 values(?,?,?,?,?,?,?,?,?,?)";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getReleaseYear().getTime()));
				pst.setObject(4, film.getOriginalLanguage().getLanguageId());
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7, film.getReplacement());
				pst.setInt(8, film.getRatings());
				pst.setString(9, film.getSpecialFeatures());
				pst.setObject(10, film.getCategory().getCategoryId());
				
				
				count=pst.executeUpdate();
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String sql1="select * from film order by filmid desc limit 1";
			
			//Films film1=new Films();
	         int fid=0;
			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql1);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					fid=rs.getInt(1);
					
				}		
					
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String sql2="insert into film_actors(film_id,actor_id)" + "values(?,?)";
			
			try {
				
				PreparedStatement pst=con.prepareStatement(sql2);
				List<Actor> act=film.getActor();
				
				
				for(Actor act1:act)
				{
				pst.setInt(1, fid);
				pst.setObject(2, act1.getActorId());
					
				count=pst.executeUpdate();
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			String sql3="insert into film_language(film_id,language_id)" + "values(?,?)";
			
			try {
				
				PreparedStatement pst=con.prepareStatement(sql3);
				List<Language> lanlist=film.getLanguages();
				
				for(Language lan1:lanlist){
				pst.setInt(1, fid);
				pst.setObject(2, lan1.getLanguageId());
					
				count=pst.executeUpdate();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				
			return count;
	}
	
	
	
	public List<Film> getAllFilms() {
		Connection con=getConnection();
		List<Film> films=new ArrayList<>();
		
		String sql="select film.filmid,film.title,film.description,film.releaseYear,languages.language_name,film.rentalDuration,film.length,film.replacementCost,film.ratings,film.specialFeatures,category.category_name from film join category on(film.category=category.category_id) join languages on(film.originalLanguage=languages.language_Id)";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
	
			while(rs.next())
			{
				Film film=new Film();
				
				film.setFilm_Id(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				
				Language lang=new Language();
				lang.setLanguageName(rs.getString(5));
				film.setOriginalLanguage(lang);
				
				film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				film.setLength(rs.getInt(7));
				film.setReplacement(rs.getDouble(8));
				film.setRatings(rs.getInt(9));
				film.setSpecialFeatures(rs.getString(10));
				
				Category category=new Category();
				category.setCategoryName(rs.getString(11));
				film.setCategory(category);
				
				//get multiple languages
				List<Language> languages=getLanguage(rs.getInt(1));
				film.setLanguages(languages);
				
				//get multiple actors
				List<Actor> actors=getActors(rs.getInt(1));
				film.setActor(actors);
				
				films.add(film);
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//System.out.println(films);
		return films;
}
	
	
	
	
	public int updateFilm(Film film) {
		
		Connection con=getConnection();
		String sql="update film set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=?"
				+ "	 where filmid=?";
		String sql1="delete from film_language where film_id=?";
		String sql3="delete from film_actors where film_id=?";
		
		String sql2="insert into film_language values(?,?)";
		String sql4="insert into film_actors values(?,?)";
		
		int count=0;

try {
PreparedStatement pst= con.prepareStatement(sql);
pst.setString(1, film.getTitle());
pst.setString(2, film.getDescription());
pst.setDate(3, new Date(film.getReleaseYear().getTime()));
int language=film.getOriginalLanguage().getLanguageId();
pst.setInt(4, language);
pst.setDate(5, new Date(film.getRentalDuration().getTime()));
pst.setInt(6, film.getLength());
pst.setDouble(7,film.getReplacement());
pst.setInt(8,film.getRatings());
pst.setString(9,film.getSpecialFeatures());
int category=film.getCategory().getCategoryId();
pst.setInt(10,category);
pst.setInt(11,film.getFilm_Id());
count=pst.executeUpdate();

//delete
PreparedStatement pst1= con.prepareStatement(sql1);
pst1.setInt(1, film.getFilm_Id());
count=pst1.executeUpdate();

PreparedStatement pst2= con.prepareStatement(sql3);
pst2.setInt(1, film.getFilm_Id());
count=pst2.executeUpdate();

//entering data in film_language table
PreparedStatement pst3=con.prepareStatement(sql2);
List<Language> languages=film.getLanguages();
for(Language lang:languages)
{
int langId=lang.getLanguageId();	
pst3.setInt(1, film.getFilm_Id());
pst3.setInt(2, langId);
count=pst3.executeUpdate();
}

//entering data in film_actors table
PreparedStatement pst4= con.prepareStatement(sql4);
List<Actor> actors=film.getActor();
for(Actor actor:actors)
{
int actor_id=actor.getActorId();	
pst4.setInt(1, film.getFilm_Id());
pst4.setInt(2, actor_id);
count=pst4.executeUpdate();
}

} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

return count;
	}
	
	
	
	
	
	public Film getSearchFilmByID(int id) {
		Connection con=getConnection();
		Film film=new Film();
		String sql="select * from film where filmid=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
			/*	Film film=new Film();*/
				film.setFilm_Id(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
				//Original Language
				Language lang=new Language();
				lang.setLanguageName(rs.getString(5));
				film.setOriginalLanguage(lang);
				
				//Rental Duration
				film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
				
				//length
				film.setLength(rs.getInt(7));
				
				//replacementCost
				film.setReplacement(rs.getDouble(8));
				
				//rating
				film.setRatings(rs.getInt(9));
				
				//Special Features
				film.setSpecialFeatures(rs.getString(10));
				
				Category category=new Category();
				category.setCategoryName(rs.getString(11));
				film.setCategory(category);
				
				//get multiple languages
				List<Language> languages=getLanguage(rs.getInt(1));
				film.setLanguages(languages);
				
				//get multiple actors
				List<Actor> actors=getActors(rs.getInt(1));
				film.setActor(actors);
				
				
				
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return film;
	
	}
	
	
	
	
	//------------------------------Search-----------------------------------------------------------------------
	
public List<Film> searchFilmDetails(Film film) {

		
		Connection con=getConnection();
		int count=0;
		String sql="select * from film where";
		ArrayList<Film> films=new ArrayList<Film>();
		System.out.println(film);
		if(film!=null)
		{
			if(film.getFilm_Id()>0)
			{
				
				sql+=" filmid="+film.getFilm_Id();
				
				count=1;
			}
			
			if(film.getTitle()!=null)
			{
				if(count==1)
				{
					sql+=" and title='"+film.getTitle()+"'";
				}
				else
				{
					sql+=" title='"+film.getTitle()+"'";
				}
				count=2;
			}
		

			if(film.getRatings()>0)
			{
				if(count==1||count==2)
				{
					sql+=" and ratings="+film.getRatings();
				}
				else
				{
					sql+=" ratings="+film.getRatings();
				}
				count=3;
			}
			if(film.getActor()!=null)
			{
				Actor actor=new Actor();
				List<Actor> actors=film.getActor();
				for(Actor a:actors)
					actor=a;
				if(count==1||count==2||count==3)
				{
					sql+=" and filmid In(Select film_id from film_actors where actor_id="+actor.getActorId()+")";
					
				}else
				{
				sql+=" filmid In(Select film_id from film_actors where actor_id="+actor.getActorId()+")";
				}
				count=4;
			}
			if(film.getLanguages()!=null)
			{
				Language lang=new Language();
				List<Language> langs=film.getLanguages();
			
				for(Language l:langs)
					lang=l;
				if(count==1||count==2||count==3||count==4)
				{
					sql+=" and( filmid In(Select film_id from film_language where language_id="+lang.getLanguageId()+") or filmid In( Select filmid from film where originalLanguage="+lang.getLanguageId()+"))";
					
				}else
				{
				sql+=" ( filmid In(Select film_id from film_language where language_id="+lang.getLanguageId()+") or filmid In (Select filmid from film where originalLanguage="+lang.getLanguageId()+"))";
				
				}
				count=5;
			}
		
			 
			if(film.getReleaseYear()!=null)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
				else
				{
					sql+=" releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
				}
				count=6;
			}
			System.out.println(sql);
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
			
				while(rs.next())
				{
					Film film1=new Film();
					film1.setFilm_Id(rs.getInt(1));
					film1.setTitle(rs.getString(2));
					film1.setDescription(rs.getString(3));
					film.setReleaseYear(rs.getDate(4));
					
					
					
					
					
					String subsql;
					subsql="select language_name from languages where language_id="+rs.getInt(5);
					PreparedStatement pst1=con.prepareStatement(subsql);
					ResultSet rs3=pst1.executeQuery();
					Language lang=new Language();
					if(rs3.next())
					{
						lang.setLanguageId(rs.getInt(5));
						lang.setLanguageName(rs3.getString(1));
					}
					film1.setOriginalLanguage(lang);
					film1.setRentalDuration(rs.getDate(6));
					film1.setLength(rs.getInt(7));
					film1.setReplacement(rs.getInt(8));
					film1.setRatings(rs.getInt(9));
					film1.setSpecialFeatures(rs.getString(10));
					
					subsql="select category_name from category where category_id="+rs.getInt(11);
					PreparedStatement pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
					if(rs3.next())
					{
						Category cat=new Category();
						cat.setCategoryId(rs.getInt(11));
						cat.setCategoryName(rs3.getString(1));
						film1.setCategory(cat);
					}
					
					subsql="select language_id from film_language where film_id="+rs.getInt(1);
					System.out.println(rs.getInt(1));
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Language> languages=new ArrayList<>();
					while(rs3.next())
					{
												
						String subsql1="select language_name from languages where language_Id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Language langs=new Language();
							langs.setLanguageId(rs3.getInt(1));
							langs.setLanguageName(rs1.getString(1));
							languages.add(langs);
							
						}
					}
					film1.setLanguages(languages);
					subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
				
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Actor> actors=new ArrayList<>();
					while(rs3.next())
					{
						String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Actor actr=new Actor();
							actr.setFirstName(rs1.getString(1));
							actr.setLastName(rs1.getString(2));
							actr.setActorId(rs3.getInt(1));
							actors.add(actr);
							
						}
					}
					film1.setActor(actors);
					film1.setLanguages(languages);
					System.out.println(film1);
					films.add(film1);
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		
		return films;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//-------------------General Functions--------------------------------------------------------------------//
	
	public List<Language> getLanguage(int filmId)
	{
		List<Language> languages=new ArrayList<>();
		int filmid=filmId;
		String sql="select languages.language_Id,languages.language_name from languages where language_Id in(select language_id from film_language where film_id=" + filmid +")";

		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguageId(rs.getInt(1));
				lang.setLanguageName(rs.getString(2));
				languages.add(lang);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
		
	}
	
	
	
	//get multiple actors
	
	public List<Actor> getActors(int filmId)
	{
		List<Actor> actors=new ArrayList<>();
		int filmid=filmId;
		String sql="select actors.actor_id,actors.firstName,actors.lastName from actors where actor_id in(select actor_id from film_actors where film_id=" + filmid +")";

		
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Actor actor=new Actor();
				actor.setActorId(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				
				actors.add(actor);
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return actors;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@Override
	public boolean deleteFilm(int filmid) {

		boolean flag=false;
		int count=0;
		Connection con=getConnection();
		String sql="delete from film_language where film_id=?";
		String sql1="delete from film_actors where film_id=?";
		String sql2="delete from film where filmid=?";
		try {
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setInt(1, filmid);
			count=pst.executeUpdate();
			
			PreparedStatement pst1=con.prepareStatement(sql1);
			pst1.setInt(1, filmid);
			count=pst1.executeUpdate();
			
			PreparedStatement pst2= con.prepareStatement(sql2);
			pst2.setInt(1, filmid);
			count=pst2.executeUpdate();
			
			if(count>0)
				flag=true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
