package com.flp.fms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;


/**
 * Servlet implementation class ListAllFilm
 */
public class ListAllFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceImpl();
		
		List<Film> filmList=filmService.getAllFilms();
		System.out.println(filmList.size());
		
		PrintWriter out=response.getWriter();
		
		

		out.println( "<h2 align='center'>List Of Films</h2>"
				+ "<table id=\"tblid\" class=\"table table-bordered\">"
				+ "<thead><tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Actors</th>"
				+ "<th>Category</th>"
				+ "</tr></thead><tbody>");
		
		
		
		

		for(Film film:filmList){
			List<Language> languages=film.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguageName()+",";
			}
			
			List<Actor> actors=film.getActor();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getFirstName()+" "+actor.getLastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film.getFilm_Id()+"</td>");
			out.println("<td>"+film.getTitle()+"</td>");
			out.println("<td>"+film.getDescription()+"</td>");
			out.println("<td>"+film.getReleaseYear()+"</td>");
			out.println("<td>"+film.getOriginalLanguage().getLanguageName()+"</td>");
			out.println("<td>");
			List<Language> langList=film.getLanguages();
			
			for(int i=0;i<langList.size();i++)
			{
				 Language lang=langList.get(i);
				out.println(""+lang.getLanguageName()+"");
			}
								
			out.println("</td>");
			out.println("<td>"+film.getRentalDuration()+"</td>");
			out.println("<td>"+film.getLength()+"</td>");
			out.println("<td>"+film.getReplacement()+"</td>");
			out.println("<td>"+film.getRatings()+"</td>");
			out.println("<td>"+film.getSpecialFeatures()+"</td>");
			
			out.println("<td>");
			List<Actor> actorList=film.getActor();
			
			for(int j=0;j<actorList.size();j++)
			{
				Actor actor=actorList.get(j);
				out.println(""+actor.getFirstName()+" "+actor.getLastName());
				
			}
								
			out.println("</td>");
			
			out.println("<td>"+film.getCategory().getCategoryName()+"</td>");
			out.println("</tr>");
		}
			
		out.print("</tbody></table>");
		
		

	}

	
}
