package com.flp.fms.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Film;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class DeleteFilmServlet1
 */
public class DeleteFilmServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        IFilmService filmService=new FilmServiceImpl();
       
        String filmid=request.getParameter("filmid");
		Film film=new Film();
		
	
		boolean flag=filmService.deleteFilm(Integer.parseInt(filmid));
		
		response.sendRedirect("pages/index.jsp?nextStep=deleteFilm");
		
		
		/*
		if(flag){
			request.getRequestDispatcher("../DeleteFilmServlet").forward(request, response);
		}
		*/
	}

	
	

}
