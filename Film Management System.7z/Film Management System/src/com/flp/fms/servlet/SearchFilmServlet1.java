package com.flp.fms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class SearchFilmServlet1
 */
public class SearchFilmServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService=new FilmServiceImpl();
		Film film=new Film();
		if(request.getParameter("id")!="")
			film.setFilm_Id(Integer.parseInt(request.getParameter("id")));
		if(request.getParameter("ratings")!="")
			film.setRatings(Integer.parseInt(request.getParameter("ratings")));
		if(request.getParameter("title")!="")
			film.setTitle(request.getParameter("title"));
		if(request.getParameter("releasedate11")!="")
			film.setReleaseYear(new Date(request.getParameter("releasedate11")));	
		List<Actor>actors=new ArrayList<>();
		if(Integer.parseInt(request.getParameter("actor"))>0)
		{
			Actor actor=new Actor();
			actor.setActorId(Integer.parseInt(request.getParameter("actor")));
			actors.add(actor);
			film.setActor(actors);
		}
	
	
		List<Language> languages=new ArrayList<>();
		if(Integer.parseInt(request.getParameter("language"))>0)
		{
			Language language=new Language();
			language.setLanguageId(Integer.parseInt(request.getParameter("language")));
			languages.add(language);
			film.setLanguages(languages);
		}
		
		List<Film> films=filmService.searchFilmDetails(film);
		PrintWriter out=response.getWriter();
		StringBuffer br = new StringBuffer();
		String filmLists = "";
		
		if(films.isEmpty())
		{	br.append("<html>");
			br.append("<h2> Results Not found!<h2>");
			br.append("</html>");
		}
		else{
		br.append("<html>");
		br.append("<head>"
				+"<link rel='stylesheet' type='text/css' href='CSS_Style/Styles.css'>"
				+ "</head>"
				+ "<body>"
				+ "<div style='margin-left:500px;'>  </div>"
				+ "<table border=1>"
				+ "<tr>"
				+ "<th> Film Id </th>"
				+ "<th> Title </th>"
				+ "<th>	Description	</th>"
				+ "<th>	Release Year	</th>"
				+ "<th>	Original Language	</th>"
				+ "<th>	Rental Duration	</th>"
				+ "<th> Other Lanugages"
				+ "<th> Actors"
				+ "<th>	Length	</th>"
				+ "<th>	Replacement Cost	</th>"
				+ "<th>	Category	</th>"
				+ "</tr>");
		
			
			for(Film film1:films){
				br.append("<tr>");
				br.append("<td>"+film1.getFilm_Id()+"</td>");
				br.append("<td>"+film1.getTitle()+"</td>");
				br.append("<td>"+film1.getDescription()+"</td>");
				br.append("<td>"+film1.getReleaseYear()+"</td>");
				br.append("<td>"+film1.getOriginalLanguage().getLanguageName()+"</td>");
				br.append("<td>"+film1.getRentalDuration()+"</td>");
				List<Language>langs=new ArrayList<>();
				langs=film1.getLanguages();
				br.append("<td>");
				for(Language lang:langs)
					br.append(lang.getLanguageName());
				br.append("</td>");
				List<Actor> actors1 =new ArrayList<>();
				actors1=film1.getActor();
				br.append("<td>");
				for(Actor act:actors1)
					br.append(act.getFirstName()+" "+act.getLastName());
				br.append("</td>");
				br.append("<td>"+film1.getLength()+"</td>");
				br.append("<td>"+film1.getReplacement()+"</td>");
				br.append("<td>"+film1.getCategory().getCategoryName()+"</td>");
			
				br.append("</tr>");
			}
				br.append("</table></body>");
	
				br.append("</html>");
			}
		
		
		filmLists = br.toString();
		response.sendRedirect("pages/index.jsp?nextStep=search&filmList='"+URLEncoder.encode(filmLists) +"'");

		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
