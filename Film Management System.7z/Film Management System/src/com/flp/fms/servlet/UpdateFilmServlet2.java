package com.flp.fms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class UpdateFilmServlet2
 */
public class UpdateFilmServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService=new FilmServiceImpl();
		Film film=new Film();
		
		film.setFilm_Id(Integer.parseInt(request.getParameter("filmid")));
		film.setTitle(request.getParameter("title"));
		film.setDescription(request.getParameter("description"));
		
	    String rd=request.getParameter("releasedate11");
	    Date relDate=new Date(rd);
		film.setReleaseYear(relDate);
	    
	    /*
	    Date releaseDate;
		film.setReleaseYear(releaseDate);*/
		/*try {
			releaseDate = new SimpleDateFormat("MM/dd/yyyy").parse(request.getParameter("releasedate11"));
			film.setReleaseYear(releaseDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	*/
		
	/*
		String language=request.getParameter("language");
		film.setOriginalLanguage(language);*/
		Language lang=new Language();
		lang.setLanguageId(Integer.parseInt(request.getParameter("language")));
		film.setOriginalLanguage(lang);
		
		String rentdate=request.getParameter("rentdate");
		Date rentDate=new Date(rentdate);
		film.setRentalDuration(rentDate);
		
		int len=Integer.parseInt(request.getParameter("length"));
		film.setLength(len);
		
		double ct=Double.parseDouble(request.getParameter("cost"));
		film.setReplacement(ct);
		
		int rt=Integer.parseInt(request.getParameter("rating"));
		film.setRatings(rt);
		
		film.setSpecialFeatures(request.getParameter("features"));
		/*
		film.setOriginalLanguage(request.getParameter("category"));*/
		
		Category category=new Category();
		category.setCategoryId(Integer.parseInt(request.getParameter("category")));
		film.setCategory(category);
		
		//other Lang
		
		String[]str=request.getParameterValues("othrlang");
		List<Language>langList=new ArrayList<>();
		for(String str1:str){
		Language lang1=new Language();
		lang1.setLanguageId(Integer.parseInt(str1));
		langList.add(lang1);
		
		}
		film.setLanguages(langList);
		
		//actors
		
		String[]str1=request.getParameterValues("actors");
		List<Actor>actorList=new ArrayList<>();
		for(String act:str1){
		Actor actor=new Actor();
		actor.setActorId(Integer.parseInt(act));
		actorList.add(actor);
				
		}
		
		film.setActor(actorList);
			
		
		System.out.println(film);
		PrintWriter out=response.getWriter();
		int count=filmService.updateFilm(film);
		if(count > 0)
		{
			response.sendRedirect("pages/index.jsp?nextStep=filmUpdated");
		}
		
		
		
		
		
	}

}
