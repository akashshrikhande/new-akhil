package com.flp.fms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class UpdateFilmServlet1
 */
public class UpdateFilmServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorService=new ActorServiceImpl();
		IFilmService filmService=new FilmServiceImpl();
		

        int filmid=Integer.parseInt(request.getParameter("id"));
		
		Film film=filmService.getSearchFilmByID(filmid);
		
		List<Actor> actorList=actorService.getActors();
		List<Language> languageList=filmService.getLanguages();
		List<Category> categoryList=filmService.getCategory();
		
		PrintWriter out=response.getWriter();
		out.println("<HTML>");
		out.println(" <HEAD>");
		out.println("  <TITLE>TableLess Form</TITLE>");
		out.println("  <META name=\"Author\" Content=\"Bit Repository\">");
		out.println("  <META name=\"Keywords\" Content=\"form, divs\">");
		out.println("  <META name=\"Description\" Content=\"A CSS Tableless Form Design\">");
		out.println("");
		out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/style1.css\" />");
		out.println(" <script src=\"http://code.jquery.com/jquery-1.10.2.js\"></script>");
		out.println(" <script src=\"http://code.jquery.com/ui/1.11.0/jquery-ui.js\"></script>");
		out.println(" <link rel=\"stylesheet\" href=\"http://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css\">");
		
		out.println("");
		out.println("</HEAD>");
		out.println("");
		out.println(" <BODY>");
		out.println(" ");
		out.println("<center>");
		out.println("");
		out.println("<div class=\"m\">");
		out.println("");
		out.println("<form name=\"register\" method=\"post\" action=\"../UpdateFilmServlet2\">");
		

		
		
		
		out.println("<fieldset><legend>ADD FILM</legend>");
		out.println("");
		out.println("<div class=\"a\"><div class=\"l\">Title :</div><div class=\"r\"><INPUT type=\"text\" value=\" " +film.getTitle() +" \" name=\"title\"></div></div>");
		out.println("");
		
		out.println("<div class=\"a\"><div class=\"l\">Description :</div><div class=\"r\"><TEXTAREA NAME=\"description\" ROWS=\"5\" COLS=\"25\"> " + film.getDescription()+"</TEXTAREA></div></div>");
		out.println("");
		out.println("<div class=\"a\"><div class=\"l\">Release Year :</div><div class=\"r\"><INPUT type=\"text\" value=\" " +film.getReleaseYear() +" \" name=\"releasedate11\" class='datepick' id='releasedate11'>  </div></div>");
		out.println("");
		out.println("<div class=\"a\"><div class=\"l\">Original Language :</div><div class=\"r\">");
		out.println("<select name=\"language\" \">" );
		for(Language lang:languageList){
			if(lang.getLanguageName().equals(film.getOriginalLanguage().getLanguageName())){
				out.print("<option value='"+lang.getLanguageId()+"' selected> "+lang.getLanguageName()+"</option>");
				
			}
			else
			out.print("<option value='"+lang.getLanguageId()+"'>"+lang.getLanguageName()+"</option>");
		}
		
		out.println("</select>");
		out.println("</div></div>   ");
		out.println("");
		out.println("");
		
		out.println("<div class=\"a\"><div class=\"l\">Other Language :</div><div class=\"r\">");
		out.println("<select name=\"othrlang\" multiple='' >");
		boolean flag1=false;
		int id2=0;
		List<Language> langFilm=film.getLanguages();
		for(Language lang:languageList){
			
			for(Language lng:langFilm){
				
				if(lang.getLanguageName().equals(lng.getLanguageName())){
					flag1=true;
					 id2=lang.getLanguageId();
				}
					//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
			}
				if(flag1==true && id2==lang.getLanguageId())
					out.print("<option value='"+lang.getLanguageId()+"' selected>"+lang.getLanguageId()+"</option>");
				else
					out.print("<option value='"+lang.getLanguageId()+"'>"+lang.getLanguageName() +"</option>");
				
			
		}
		
		out.println("</select>");
		out.println("</div></div>   ");
		out.println("");
		out.println("");
		out.println("<div class=\"a\"><div class=\"l\">Rental Duration :</div><div class=\"r\"><INPUT type=\"text\" value=\" " +film.getRentalDuration() +" \" class='datepick' name=\"rentdate\" id='rentdate' ></div></div>");
		out.println("    ");
		out.println("<div class=\"a\"><div class=\"l\">Length :</div><div class=\"r\"><INPUT type=\"text\" value="+film.getLength()+ " name=\"length\"></div></div>");
		out.println("    ");
		out.println("<div class=\"a\"><div class=\"l\">Replacement Cost :</div><div class=\"r\"><INPUT type=\"text\" value="+film.getReplacement()+ " name=\"cost\"></div></div>");
		out.println("    ");
		out.println("<div class=\"a\"><div class=\"l\">Ratings :</div><div class=\"r\"><span class=\"starRating\">");
				out.println("<input id=\"rating5\" type=\"radio\" name=\"rating\" value=\"5\">");
						out.println("<label for=\"rating5\">5</label>");
								out.println("<input id=\"rating4\" type=\"radio\" name=\"rating\" value=\"4\">");
										out.println("<label for=\"rating4\">4</label>");
												out.println("<input id=\"rating3\" type=\"radio\" name=\"rating\" value=\"3\"   >");
														out.println("<label for=\"rating3\">3</label>");
																out.println("<input id=\"rating2\" type=\"radio\" name=\"rating\" value=\"2\">");
																		out.println("<label for=\"rating2\">2</label>");
																				out.println("<input id=\"rating1\" type=\"radio\" name=\"rating\" value=\"1\" checked>");
																						out.println("<label for=\"rating1\">1</label>");
																								out.println("</span></div></div>");
		out.println("    ");
		out.println("<div class=\"a\"><div class=\"l\">Special Features :</div><div class=\"r\"><TEXTAREA NAME=\"features\" ROWS=\"5\" COLS=\"25\"> " + film.getSpecialFeatures()+"</TEXTAREA></div></div>");
		out.println("");
		
		
		out.println("<div class=\"a\"><div class=\"l\">Actors :</div><div class=\"r\">");
		out.println("<select name=\"actors\" multiple='' >");
		boolean flag=false;
		int id1=0;
		List<Actor> actFilm=film.getActor();
		for(Actor actor1:actorList){
			for(Actor actt:actFilm){
				
			if(actor1.getFirstName().equals(actt.getFirstName()) && actor1.getLastName().equals(actt.getLastName())){
				flag=true;
				 id1=actor1.getActorId();
			}
				//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
		}
			if(flag==true && id1==actor1.getActorId())
				out.print("<option value='"+actor1.getActorId()+"' selected> "+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
			else
				out.print("<option value='"+actor1.getActorId()+"' >"+actor1.getFirstName()+" "+actor1.getLastName()+"</option>");
			
		}
		
		out.println("</select>");
		out.println("</div></div>   ");
		out.println("");
		out.println("");
		
		out.println("<div class=\"a\"><div class=\"l\">Category :</div><div class=\"r\">");
		out.println("<select name=\"category\" value=" +film.getCategory().getCategoryName() + ">");
		for(Category category1:categoryList){
			if(category1.getCategoryName().equals(film.getCategory().getCategoryName())){
			out.print("<option value='"+category1.getCategoryId()+"' selected>"+category1.getCategoryName()+"</option>");
			}
			else
				out.print("<option value='"+category1.getCategoryId()+"'>"+category1.getCategoryName()+"</option>");
		}
		out.println("</select>");
		out.println("</div></div>   ");
		out.println("");
		out.println("<div class=\"a\"><div class=\"l\"></div><div class=\"r\"><INPUT type=\"hidden\" value="+film.getFilm_Id()+ " name=\"filmid\"></div></div>");
		out.println("");
		out.println("");
		out.println("<div class=\"a\"><div class=\"l\">&nbsp;</div><div class=\"r\"><INPUT class=\"button\" type=\"submit\" name=\"submit\" value=\"Save\">");
		out.println("    ");
		out.println("    <INPUT class=\"button\" type=\"reset\" name=\"reset\" value=\"Clear\"></div></div>");
		out.println("    ");
		out.println("   ");
		out.println("");
		out.println("<div class=\"a\"></div>");
		out.println("");
		out.println("</fieldset>");
		out.println("");
		out.println("</form>");
		out.println("");
		out.println("</div>");
		out.println("");
		out.println("</center>");
		out.println(""); 
		
		out.println("<script>");
		
		out.println("$(document).ready(function() {");
		out.println("  $(function() {"); 
		
		out.println("  $( '#rentdate' ).datepicker();");
		out.println(" $('#format').change(function() {");
		out.println("$('#rentdate').datepicker('option', 'dateFormat', $(this).val());});" );
		out.println("  $( '#releasedate11' ).datepicker();");
		out.println(" $('#format').change(function() {");
		out.println("$('#releasedate11').datepicker('option', 'dateFormat', $(this).val());" );
		out.println(" }); }); }); </script>");
		
		
		out.println(" </BODY>");
		out.println("</HTML>");	
	}

}