package com.flp.fms.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;



/**
 * Servlet implementation class SearchFilmServlet
 */
public class SearchFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IActorService actorService=new ActorServiceImpl();
		IFilmService filmService=new FilmServiceImpl();
		
		List<Actor> actorList=actorService.getActors();
		List<Language> langList=filmService.getLanguages();
		List<Category> categoryList=filmService.getCategory();
		List<Film> filmList=filmService.getAllFilms();

		PrintWriter out=response.getWriter();
		out.println("<HTML>");
		out.println(" <HEAD>");
		out.println("  <TITLE>TableLess Form</TITLE>");
		out.println("  <META name=\"Author\" Content=\"Bit Repository\">");
		out.println("  <META name=\"Keywords\" Content=\"form, divs\">");
		out.println("  <META name=\"Description\" Content=\"A CSS Tableless Form Design\">");
		out.println("");
		//out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"../css/style1.css\" />");
		out.println(" <script src=\"http://code.jquery.com/jquery-1.10.2.js\"></script>");
		out.println(" <script src=\"http://code.jquery.com/ui/1.11.0/jquery-ui.js\"></script>");
		out.println(" <link rel=\"stylesheet\" href=\"http://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css\">");
		
		out.println("");
		out.println("</HEAD>");
		out.println("");
		out.println(" <BODY>");
		out.println(" ");
		
		
		
		
		out.println("<div class=\"m\">");
		out.println("");
		out.println("<form name=\"search\" method=\"post\" action=\"../SearchFilmServlet1\">");
		out.println("<fieldset><legend>SEARCH FILM</legend>");
		out.println("");
		out.println("<table><tr><th>Search by Film: </th><th></th><th></th></tr>");
		out.println("<table><tr><td>Id: </td><td><input type='text' name='aid'></td><td>");
		out.println("<select name=\"id\" >");
		out.println("<option value='0'>-Select-</option>");
		for(int i=0;i<filmList.size();i++){ 
			Film film=filmList.get(i);
		out.println("<option value='"+ film.getFilm_Id()+"'>" + film.getFilm_Id()+"</option>");
		}
		
		out.println("</select></td>");
		
		out.println("<tr><td>Title: </td><td><input type='text' name='title'></td><td></td></tr>");
		out.println("<tr><td>Ratings: </td><td><input type='text' name='rat'></td><td>");
		
		out.println("<select name=\"ratings\" >");
		out.println("<option value='0'>-Select-</option>");
		for(int i=1;i<6;i++){
			out.println("<option value='"+ i +"'>" + i+"</option>");
		}
		out.println("</select></td></tr>");
		
		out.println("<tr><td>Actor: </td><td><input type='text' name='act'></td><td>");
		
		out.println("<select name=\"actor\" >");
		out.println("<option value='0'>-Select-</option>");
		for(int i=0;i<actorList.size();i++){
			Actor actor=actorList.get(i);
		out.println("<option value='"+ actor.getActorId()+"'>"+actor.getFirstName()+" "+actor.getLastName()+"   </option>");
		}
		
		out.println("</select></td></tr>");
		
		out.println("<tr><td>Release Date: </td><td><INPUT type=\"text\" class='datepick' id='releasedate11' name=\"releasedate11\"> </td><td> ");
		
		out.println("<tr><td>Language: </td><td><input type='text' name='lang'></td><td>");
		
		out.println("<select name=\"language\" >");
		out.println("<option value='0'>-Select-</option>");
		for(int i=0;i<langList.size();i++){
			Language lang=langList.get(i);
		out.println("<option value='"+ lang.getLanguageId()+"'>"+ lang.getLanguageName()+"</option>");
		}
		
		out.println("</select></td></tr>");
		
		
		
		out.println("<tr><td></td><td><input type='submit' value='Search'></td></tr>");

		out.println("</table>");
		out.println("</div>   ");
		out.println("");
		out.println("");
		
		
		
		
		out.println("</div>   ");
		out.println("");
		out.println("");

out.println("<script>");
		
		out.println("$(document).ready(function() {");
		out.println("  $(function() {"); 
		
		out.println("  $( '#rentdate' ).datepicker();");
		out.println(" $('#format').change(function() {");
		out.println("$('#rentdate').datepicker('option', 'dateFormat', $(this).val());});" );
		out.println("  $( '#releasedate11' ).datepicker();");
		out.println(" $('#format').change(function() {");
		out.println("$('#releasedate11').datepicker('option', 'dateFormat', $(this).val());" );
		out.println(" }); }); }); </script>");
		

		out.println(" </BODY>");
		out.println("</HTML>");	
		
		
		
		
}
}