package com.flp.fms.domain;

public class Language {

	//Instance variables
	private int languageId;
	private String languageName;
	
	//No argument constructor
	public Language() {
		super();
	}
	
	
	//Constructor with arguments
	public Language(int languageId, String languageName) {
		super();
		this.languageId = languageId;
		this.languageName = languageName;
	}
	
	
	
	//Getters and Setters
	public int getLanguageId() {
		return languageId;
	}
	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}
	public String getLanguageName() {
		return languageName;
	}
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	
	
	
	//To string method
	@Override
	public String toString() {
		return "Language [languageId=" + languageId + ", languageName=" + languageName + "]";
	}
	
	
	
	
	
	
}
