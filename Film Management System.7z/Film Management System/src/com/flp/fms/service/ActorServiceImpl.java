package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.ActorDaoImpl;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService {

	@Override
	public List<Actor> getActors() {
		IActorDao actors=new ActorDaoImpl();
		return actors.getActors();
	}

}
