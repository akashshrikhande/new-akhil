package com.flp.fms.service;

import java.util.List;

import com.flp.fms.dao.FilmDaoImpl;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService {

	IFilmDao filmDao=new FilmDaoImpl();
	
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	@Override
	public int addFilm(Film film) {
		
		return filmDao.addFilm(film);
	}

	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public boolean deleteFilm(int filmid) {
		
		return filmDao.deleteFilm(filmid);
	}

	@Override
	public int updateFilm(Film film) {
		
		return filmDao.updateFilm(film);
	}

	@Override
	public List<Film> searchFilmDetails(Film film) {
		
		return filmDao.searchFilmDetails(film);
	}

	@Override
	public Film getSearchFilmByID(int id) {
		
		return filmDao.getSearchFilmByID(id);
	}

}
