package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;



public interface IActorService {
	
	public List<Actor> getActors();
	

}
