package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmService {
	
	public List<Language> getLanguages();
	public List<Category> getCategory();
	public int addFilm(Film film);
	public List<Film> getAllFilms();
	public boolean deleteFilm(int filmid);
	public int updateFilm(Film film);
	public List<Film> searchFilmDetails(Film film);
	public Film getSearchFilmByID(int id);
}
