package com.flp.fms.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class testClassDao {



	FilmDaoImplForList filmDao=new FilmDaoImplForList();
	ActorDaoImplForList actorDao=new ActorDaoImplForList();



	//1.Test case for get all languages are same
	@Test
	public void testGetLanguages(){


		List<Language>languages=new ArrayList<>();

		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Marathi"));
		languages.add(new Language(4, "French"));
		languages.add(new Language(5, "Kananda"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		languages.add(new Language(8, "Gujrati"));
		languages.add(new Language(9, "Punjabi"));
		languages.add(new Language(10, "Bhojpuri"));
		assertEquals(languages, filmDao.getLanguages());

	}
	
	//2.Test case for languages are not same add additional value 
	
	@Test
	public void testGetLanguagesNotSame(){


		List<Language>languages=new ArrayList<>();

		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Marathi"));
		languages.add(new Language(4, "French"));
		languages.add(new Language(5, "Kananda"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		languages.add(new Language(8, "Gujrati"));
		languages.add(new Language(9, "Punjabi"));
		languages.add(new Language(10, "Bhojpuri"));
		languages.add(new Language(10, "telugu"));
		assertNotEquals(languages, filmDao.getLanguages());

	}
	

	//3.Test case for get all categories
	@Test
	public void testGetCategory(){

		List<Category> category=new ArrayList<>();

		category.add(new Category(1, "adventure"));
		category.add(new Category(2, "Comedy"));
		category.add(new Category(3, "Horror"));
		category.add(new Category(4, "Romantic"));
		category.add(new Category(5, "Animation"));
		category.add(new Category(6, "Science Fiction"));


		assertEquals(category, filmDao.getCategory());

	}

	//4.Test case for get all categories not same as data base
	@Test
	public void testGetCategoryNotSame(){

		List<Category> category=new ArrayList<>();

		category.add(new Category(1, "adventure"));
		category.add(new Category(2, "Comedy"));
		category.add(new Category(3, "Horror"));
		category.add(new Category(4, "Romantic"));
		category.add(new Category(5, "Animation"));
		category.add(new Category(6, "Science Fiction"));
		category.add(new Category(7, "3D"));

		assertNotEquals(category, filmDao.getCategory());

	}


	//5.Test case for get actors
	@Test
	public void testGetActor(){
		List<Actor> actor1=new ArrayList<>();

		actor1.add(new Actor(1, "salman", "khan"));
		actor1.add(new Actor(2, "tom", "cruise"));
		actor1.add(new Actor(3, "shahrukh", "khan"));
		actor1.add(new Actor(4, "Amir", "khan"));
		actor1.add(new Actor(5, "Vin", "Diesel"));
		actor1.add(new Actor(6, "Will", "Smith"));
		actor1.add(new Actor(7, "Nicholas", "Cage"));
		actor1.add(new Actor(8, "Aditya Roy", "kapoor"));
		actor1.add(new Actor(9, "katrina", "kaif"));
		actor1.add(new Actor(10, "Sonam", "Kapoor"));
		actor1.add(new Actor(11, "Dipika", "padukone"));
		actor1.add(new Actor(12, "Sushmita", "Sen"));
		actor1.add(new Actor(13, "Sonakshi", "Sinha"));
		actor1.add(new Actor(14, "Kareena", "Kapoor"));
		actor1.add(new Actor(15, "Aliya", "Bhatt"));
		actor1.add(new Actor(16, "Parineeti", "chopra"));
		actor1.add(new Actor(17, "Sylvester", "Stallone"));
		actor1.add(new Actor(18, "  Arnold", "Schwarzenegger"));
		
		assertNotEquals(actor1, actorDao.getActorList());

	}
	
	//6.test  case for actor object is null
		@Test
		public void testActorObjectNull(){
			
			Actor actor=null;
			assertEquals(actor,null);
			
		}
	
		
	//7.test case for get all film (Number of films in FILM table)
			
		    @Test
			public void testgetallfilms(){
				assertNotEquals(2,filmDao.getAllFilms().size());
		         }

		    
	 //8.test case for delete film
			@Test
			public void testFilmDeleted(){

		    	assertNotEquals(2,filmDao.deleteFilm(15));
			}
			
	//9.update film
			@Test
			public void testUpdateFilm(){

				Film film=new Film();
				film.setFilmId(5);
				film.setTitle("The notebook");
				film.setDescription("aaaa");
				Date d=new Date("15-apr-2016");
				film.setReleaseYear(d);

				Language lang=new Language();
				lang.setLanguage_Id(1);
				film.setOriginalLanguage(lang);
				Date d1=new Date("13-may-2016");
				film.setRentalDuration(d1);
				film.setLength(11);
				film.setReplacementCost(1111);
				film.setRatings(2);
				film.setSpecialFeatures("asdfg");
				Category category=new Category();
				category.setCategory_Id(1);
				film.setCategory(category);

				List<Language> langs=new ArrayList<>();
				Language lang1=new Language();
				lang1.setLanguage_Id(2);
				langs.add(lang);
				langs.add(lang1);
				film.setLanguage(langs);

				List<Actor> actors=new ArrayList<>();
				Actor actor1=new Actor();
				actor1.setActor_Id(1);
				Actor actor2=new Actor();
				actor2.setActor_Id(2);
				actors.add(actor1);
				actors.add(actor2);
				film.setActors(actors);

				assertEquals(1, filmDao.updateFilm(15, film));


			}
		
			//10. test case to return list of categories
			@Test
			public void toReturnListOfCategories()
			{
				assertNotEquals(3, filmDao.getCategory().size());
			}
			
			
			//11.test to return list of languages
			@Test
			public void toReturnListofLanguages()
			{
				assertNotEquals(5, filmDao.getLanguages().size());
			}
			

			
			
}
