package com.flp.fms.service;

import java.util.List;
import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;



public class ActorServiceImpl implements IActorService{




 ActorDaoImplForList actorDao=new ActorDaoImplForList();

	//To get List Of actor
	@Override
	public List<Actor> getActorList() {
		// TODO Auto-generated method stub
		return actorDao.getActorList();
	}

	//To add Actor List to Db
	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return actorDao.addActor();
	}

	//To add Actor to Db
	@Override
	public void addActor(Actor actor) {
		// TODO Auto-generated method stub
		actorDao.addActor(actor);
		
	}
 
  @Override
  public List<Actor> getActor() {
	// TODO Auto-generated method stub
	return actorDao.getActorList();
    }
  
  
  
//To remove Actor by Id
	@Override
	public int removeActor(int id) {
		
		return actorDao.removeActor(id);
	}

	
	
		
	}
		
			
		
			
			
		

	
