package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public interface IFilmService {
	public List<Language> getLanguages();
	public List<Category> getCategory();
	
	public void addFilm(Film film);
//	public Map<Integer, Film> getAllFilms();
	
	public ArrayList<Film> getAllFilms();
	
	Boolean deleteFilm(int filmid);
	
	public List<Film> searchFilm(Film film);
	
	public int updateFilm(int id,Film film);
	
	public boolean isValidUser(UserLogin login);
}
