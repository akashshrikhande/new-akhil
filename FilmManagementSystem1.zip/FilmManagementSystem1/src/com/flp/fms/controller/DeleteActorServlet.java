package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.ActorServiceImpl;

/**
 * Servlet implementation class DeleteActorServlet
 */
public class DeleteActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
		System.out.println("in deleteActorServlet");
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		ActorServiceImpl actorService=new ActorServiceImpl();
		int count=actorService.removeActor(id);
		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>");
		out.print("<body>");
		System.out.println(count);
		if(count>0){
			request.getRequestDispatcher("DeleteActorServlet").forward(request, response);
		}
		out.print("</body>");
		out.println("<html>");
		out.println("<body><center><h1><font color='pink'>Actor Deleted Successfully.. </h1></body>");
		out.println("</html>");
	}
	
}
