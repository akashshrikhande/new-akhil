package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class CreateActor
 */
public class CreateActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		PrintWriter out=response.getWriter();
		IFilmService filmService=new FilmServiceImpl();
		ActorDaoImplForList actorService= new ActorDaoImplForList();
		
		out.print("<html>");
		out.print(	"<body>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");

		out.print("<form name='CreateActor' method='post' action='AddActor' >");
		out.print( "<table>"
				+ "<tr>"
				+ "<td><h3>Enter Actor FirstName<td>"
				+ "<td><input type='text' name='FirstName' ></td></tr>"
				+ "<tr>"
				+ "<td><h3>Enter Actor LastName<td>"
				+ "<td><input type='text' name='LastName' ></td></tr>"
				+ "</table>"
				+ "<tr><td><input type='submit' value='Submit'></td><tr>"
				);
		out.print( "</body>");
		out.print( "</html>");
	}
	}


