package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.domain.Actor;

/**
 * Servlet implementation class AddActor
 */
public class AddActor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	

		Actor actor = new Actor();
		ActorDaoImplForList actorService = new ActorDaoImplForList();
		actor.setFirst_Name(request.getParameter("FirstName"));
		actor.setLast_Name(request.getParameter("LastName"));

		actorService.addActor(actor);
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<body><center><h1><font color='pink'>Actor Added Successfully.. </h1></body>");
		out.println("</html>");
	}


	}


