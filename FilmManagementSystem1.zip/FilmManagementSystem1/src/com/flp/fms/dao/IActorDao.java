package com.flp.fms.dao;

import java.util.List;


import com.flp.fms.domain.Actor;

public interface IActorDao {

	public List<Actor> getActorList();
	
	public List<Actor> addActor();
	public void addActor(Actor actor);
	
	public int removeActor(int id) ;
	//public Actor getActorByID(int id) ;
}

