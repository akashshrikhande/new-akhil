package com.flp.fms.domain;

public class Category {

	
	//private fields category
	private int category_Id;
	private String Category_Name;
	
	
	//No argument constructor for category
	public Category(){}


	// Constructor with fields for category
	public Category(int category_Id, String category_Name) {
		super();
		this.category_Id = category_Id;
		Category_Name = category_Name;
	}


	//Getter and Setter for category
	public int getCategory_Id() {
		return category_Id;
	}


	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}


	public String getCategory_Name() {
		return Category_Name;
	}


	public void setCategory_Name(String category_Name) {
		Category_Name = category_Name;
	}

	
	
	// To string for category

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Category_Name == null) ? 0 : Category_Name.hashCode());
		result = prime * result + category_Id;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (Category_Name == null) {
			if (other.Category_Name != null)
				return false;
		} else if (!Category_Name.equals(other.Category_Name))
			return false;
		if (category_Id != other.category_Id)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", Category_Name=" + Category_Name + "]";
	}
	
	
	
	
	
	
	
}
