

function istitlevalidate()  
{   
		var filmtitle=filmf.filmtitle.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmtitle.match(letters))  
		{  
			document.getElementById("titleerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titleerr").innerHTML="*Title should only contain alphabet"; 
			filmtitle.focus();  
			return false;  
		}  
}  

   function isdescriptionvalidate()  
   {   
		var filmdescription=filmf.filmdescription.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmdescription.match(letters))  
		{  
			document.getElementById("descerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("descerr").innerHTML="*Description should contain only alphabets"; 
			filmdescription.focus();  
			return false;  
		}  
}  

   function islengthvalid(){
		
		var filmlength=filmf.filmlength.value;

	    //if(isNaN(filmlength)||filmlength>1 || filmlength<1000){
	    	
	    	 if(filmlength>=1 && filmlength<=1000){
	    	
	    	
	    	document.getElementById("lenghterr").innerHTML="";
			return true;  
	    }
	    else
	    {
	    	document.getElementById("lenghterr").innerHTML="*Length should be between 1 to 1000"; 
	    	filmlength.focus();  
			return false; 
	    }	
	}
   
   
   function isrentaldurationvalid(){
		
		var releasedate=filmf.releasedate.value;
		var rentalduration=filmf.rentalduration.value;


	    	
	    	 if(rentalduration>releasedate){
	    	
	    	
	    	document.getElementById("rentaldurationerr").innerHTML="";
			return true;  
	    }
	    else
	    {
	    	document.getElementById("rentaldurationerr").innerHTML="*Rental Date should be Greater than Release Date"; 
	    	rentalduration.focus();  
			return false; 
	    }
	    
		
	}

   
   