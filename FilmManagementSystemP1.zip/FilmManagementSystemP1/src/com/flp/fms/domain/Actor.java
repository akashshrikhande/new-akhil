package com.flp.fms.domain;

public class Actor {
	//private field
	private int actor_Id;
	private String firstName,lastName;
	//No argument constructor
	public Actor(){
		
	}
	//Constructor with fields
	public Actor(int actorId, String firstName, String lastName) {
		super();
		this.actor_Id = actorId;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	//Getters and setters
	public int getActor_Id() {
		return actor_Id;
	}
	public void setActorId(int actor_Id) {
		this.actor_Id = actor_Id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}

}
