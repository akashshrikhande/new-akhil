package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {

	@Override
	public List<Actor> getActors() {
		
		List<Actor> actors = new ArrayList<>();
		
		actors.add(new Actor(101, "Salman", "Khan"));
		actors.add(new Actor(102, "Ajay", "Devgan"));
		actors.add(new Actor(103, "Amir", "khan"));
		actors.add(new Actor(104, "Madhuri", "Dikshit"));
		actors.add(new Actor(105, "Priyanka", "Chopra"));
		actors.add(new Actor(106, "Ranveer", "Singh"));
		
		return actors;
	}

}
