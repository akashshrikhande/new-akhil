package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao {

	
	HashMap<Integer, Film> filmRepository = new HashMap<>();
	
	
	@Override
	public List<Language> getLanguages() {
		
		List<Language> languages=new ArrayList<>();
		
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kannada"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		return languages;
	}

	@Override
	public List<Category> getCategories() {
		
		List<Category> categories = new ArrayList<>();
		
		categories.add(new Category(1,"comedy"));
		categories.add(new Category(2,"romantic"));
		categories.add(new Category(3,"thriller"));
		categories.add(new Category(4,"suspense"));
		categories.add(new Category(5,"drama"));
		categories.add(new Category(6,"fiction"));
		
		return categories;
	}

	@Override
	public void addFilm(Film film) {

		filmRepository.put(film.getFilm_Id(), film);
		
	}

	@Override
	public Map<Integer, Film> getAllFilm() {
		
		return filmRepository;
	}

	
	//SEARCHING FILM FROM THE REPOSITORY USING ID
	@Override
	public Film searchFilm(int filmId) {
			
		return filmRepository.get(filmId);
	}
	
	
	//SEARCHING FILM USING TITLE
	@Override
	public Film searchFilm(String title) {
		
		Film result = null;
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			if(film.getTitle().equals(title)){
				
				result = film;
				break;
			}
		}
		
		return result;
	}
	
	
	//SEARCHING FILM USING RATING
	@Override
	public List<Film> searchFilmByRating(int rating) {

		List<Film> selectedFilms = new ArrayList<>();
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getRatings()==rating){
				
				selectedFilms.add(film);
			}
		}
		
		
		return selectedFilms;
	}

	
	//SEARCHING FILM USING LANGUAGE
	@Override
	public List<Film> searchFilm(Language language) {
		
		List<Film> selectedFilms = new ArrayList<>();
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			//if original language is same as entered language
			if(film.getOriginalLanguage().getLanguageId() == language.getLanguageId()){
				
				selectedFilms.add(film);
			}
			
			//if film is released in entered language
			else{
				
				Set<Language> languages = new HashSet<>();
				languages = film.getLanguages();
				
				for(Language lang : languages){
					
					if(lang.getLanguageId()==language.getLanguageId()){
						
						selectedFilms.add(film);
					}
				}
			}
		
		}
		
		return selectedFilms;
	}
		
	
	
	//SEARCHING FILM USING ACTOR
	@Override
	public List<Film> searchFilm(Actor actor) {
		
		List<Film> selectedFilms = new ArrayList<>();
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			Set<Actor> actors = new HashSet<>();
			actors = film.getActors();
			
			for(Actor act : actors){
				
				if(act.getActor_Id()==actor.getActor_Id()){
					
					selectedFilms.add(film);
				}
				
			}
		}
		
		
		return selectedFilms;
	}

		
	
	//SEARCH FILM BY 3 PARAMETERS
	@Override
	public Film searchFilm(String title, Date releaseDate, int rating) {
		
		Film result=null;
		
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getTitle().equals(title) && film.getReleaseYear().equals(releaseDate) && film.getRatings()==rating){
				
				result =film;
				break;
			}
		}
		
		return result;
	}

	
	//FUNCTION TO REMOVE FILM BY ID
	@Override
	public void removeFilm(int filmId) {
		
		filmRepository.remove(filmId);
		
	}

	//FUNCTION TO REMOVE FILM BY TITLE
	@Override
	public void removeFilm(String title) {
		
		Collection<Film> allFilms = filmRepository.values();
		Iterator<Film> itr = allFilms.iterator();
		
		int filmId=0;
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getTitle().equals(title)){
				
				filmId = film.getFilm_Id();
				break;
			}
		}
		
		filmRepository.remove(filmId);	
	}
	

	
	//FUNCTION TO REMOVE FILM BY RATING
	@Override
	public void removeFilmByRating(int rating) {
		
		Collection<Film> allFilms = filmRepository.values();
		Iterator<Film> itr = allFilms.iterator();
		
		Set<Integer> selectedFilmIds = new HashSet<>();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			if(film.getRatings() == rating){
				
				selectedFilmIds.add(film.getFilm_Id());	
			}
		}
		
		for(Integer filmId : selectedFilmIds){
			
			filmRepository.remove(filmId);
		}
	}

	
	//FUNCTION TO REMOVE FILM BY ACTOR
	@Override
	public void removeFilm(Actor actor) {
						
		Collection<Film> films = filmRepository.values();
		Iterator<Film> itr = films.iterator();
		
		Set<Integer> selectedFilmIds = new HashSet<>();
		
		while(itr.hasNext()){
			
			Film film = itr.next();
			
			//getting the name of all actors in the film
			Set<Actor> actors = new HashSet<>();
			actors = film.getActors();
			
			for(Actor act : actors){
				
				if(act.getActor_Id() == actor.getActor_Id()){
					
					selectedFilmIds.add(film.getFilm_Id());
				}
				
			}
		}
		
		for(Integer filmId : selectedFilmIds){
			
			filmRepository.remove(filmId);
		}

	}

	
	//FUNCTION TO UPDATE FILM
	@Override
	public void updateFilm(Film film) {
			
		addFilm(film);
	}

		

}
