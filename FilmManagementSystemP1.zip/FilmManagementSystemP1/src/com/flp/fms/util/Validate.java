package com.flp.fms.util;

public class Validate {

	public static boolean isValidTitle(String title){
		
		return title.matches("[A-Za-z0-9@., ]+");
	}
	
	public static boolean isValidDateFormat(String date){
		
		return date.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
	}
	
	public static boolean isValidLength(int length){
		
		if(length>0 && length<=1000)
			return true;
		else
			return false;
	}
	
	public static boolean isValidRating(int rating){
		
		if(rating>0 && rating<=5)
			return true;
		else
			return false;
	}

}
