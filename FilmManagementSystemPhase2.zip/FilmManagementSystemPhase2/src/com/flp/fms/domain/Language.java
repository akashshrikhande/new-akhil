package com.flp.fms.domain;

public class Language {

	//private fields
		private int languageId;
		private String languageName;
		
		
		//no argument constructor
		public Language(){
			
		}

		
		//constructor with arguments
		public Language(int languageId, String languageName) {
			super();
			this.languageId = languageId;
			this.languageName = languageName;
		}

		

		//Getters and Setters
		public int getLanguageId() {
			return languageId;
		}


		public void setLanguageId(int languageId) {
			this.languageId = languageId;
		}


		public String getLanguageName() {
			return languageName;
		}


		public void setLanguageName(String languageName) {
			this.languageName = languageName;
		}

		
		//toString method implementation
		@Override
		public String toString() {
			return "Language [languageId=" + languageId + ", languageName=" + languageName + "]";
		}
		
		
		//hashCode method implementation
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + languageId;
			result = prime * result + ((languageName == null) ? 0 : languageName.hashCode());
			return result;
		}


		//equals method implementation
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Language other = (Language) obj;
			if (languageId != other.languageId)
				return false;
			if (languageName == null) {
				if (other.languageName != null)
					return false;
			} else if (!languageName.equals(other.languageName))
				return false;
			return true;
		}
	
}
