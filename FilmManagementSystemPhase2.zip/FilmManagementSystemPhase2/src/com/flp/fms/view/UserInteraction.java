package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {

Scanner sc = new Scanner(System.in);
	
	
	//FUNCTION TO PROMPT THE USER TO ENTER FILM ID
	public int readFilmId(){
		
		System.out.println("enter film id");
		return sc.nextInt();
	}
	
	
	//FUNCTION TO PROMPT THE USER TO ENTER FILM TITLE
	public String readTitle(){
			
		System.out.println("enter film title");
		String title = sc.nextLine();
		return title;
	}
	
	
	//FUNCTION TO PROMPT THE USER TO ENTER ACTOR FIRST NAME
	public String readFirstName(){
			
		System.out.println("enter first name of Actor");
		return sc.next();
	}
	
	
	//FUNCTION TO PROMPT THE USER TO ENTER ACTOR LAST NAME
	public String readLastName(){
				
		System.out.println("enter Last name of Actor");
		return sc.next();
	}
	
	//FUNCTION TO PROMPT THE USER TO ENTER FILM RATING
	public int readRating(){
				
		System.out.println("enter film rating");
		return sc.nextInt();
	}
	
	
	//function to collect all the details for the film
	public Film addFilm(List<Language> languages,List<Category> categories,List<Actor> allActors){
		
		Film film = new Film();
		
		//Local variables
		String title;
		String releaseDate;
		Language originalLanguage;
		String rentalDuration;
		int length;
		int ratings;
		List<Language> otherLanguages;
		List<Actor> actors;
		Category category;
		
		boolean flag = false;
		
		
		//TO GET FILM TITLE AND TO VALIDATE IT
		do{
			
			System.out.println("enter film title");
			title = sc.nextLine();
			
			flag = Validate.isValidTitle(title);
			
			if(!flag)
				System.out.println("Inavlid title. Enter a valid title!");
			
		}while(!flag);
		
		film.setTitle(title);
		
		
		
		//TO GET FILM DESCRIPTION
		System.out.println("enter film description: ");
		film.setDescription(sc.nextLine());
		
		
		
		//TO GET RELEASE DATE AND TO VALIDATE IT
		do{
			
			System.out.println("enter released date [dd-mm-yyy]: ");
			releaseDate = sc.next();
			
			flag = Validate.isValidDateFormat(releaseDate);
			
			if(flag){
				
				Date currentDate = new Date();
				Date releaseYear = new Date(releaseDate);
				
				//Checking whether release date is on or before current date
				if(releaseYear.before(currentDate)||releaseYear.equals(currentDate))
					film.setReleaseYear(releaseYear);
				
				else{
					System.out.println("Invalid date. Release date should be on or before current date");
					flag = false;
				}
			}
			
			else
				System.out.println("Inavlid date format. Please enter correct format!");
			
		}while(!flag);
		
		
		
		
		//TO GET RENTAL DURATION AND TO VALIDATE IT
		do{
			
			System.out.println("enter rental duration [dd-mm-yyyy]: ");
			rentalDuration = sc.next();
			
			flag = Validate.isValidDateFormat(rentalDuration);
			
			if(flag){
				
				Date rental_duration = new Date(rentalDuration);
				
				//checking whether rental duration is on or after release date
				if(film.getReleaseYear().before(rental_duration)||film.getReleaseYear().equals(rental_duration))
					film.setRentalDuration(rental_duration);
				
				else{
					System.out.println("Invalid date. Rental duration should be on or before release date");
					flag = false;
				}
			}
			
			else
				System.out.println("Inavlid date format. Please enter correct format!");
			
		}while(!flag);
		
		
		
		//TO GET ORIGINAL LANGUAGE 
		System.out.println("enter orginal language");
		originalLanguage = selectLanguage(languages);
		film.setOriginalLanguage(originalLanguage);
				
				
		
		//TO GET OTHER LANGUAGES  
		String choice;
		otherLanguages = new ArrayList<>();
		System.out.println("Choose all the languages in which film is released");
		do{

			Language lang = selectLanguage(languages);
			
			//to check whether selected language is already added
			int flag1=0;
			if(!otherLanguages.isEmpty()){
				
				for(Language lan : otherLanguages){
					if(lan.equals(lang)){
						flag1=1;
						break;
					}	
				}
			}
			
			if(flag1!=1)
				otherLanguages.add(lang);
			else
				System.out.println("This language is already added. select another");
					
			System.out.println("do you want to enter another language? [y/n]");
			choice = sc.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
				
		film.setLanguages(otherLanguages);
		
		
		
		//TO GET FILM LENGTH AND TO VALIDATE IT
		do{
			
			System.out.println("enter length of the film minutes: ");
			length = sc.nextInt();
			
			flag = Validate.isValidLength(length);
			
			if(!flag)
				System.out.println("Invalid length. Length must be between 0 and 1000");
		}while(!flag);
		
		film.setLength(length);
	
		
		
		//TO GET REPLACEMENT COST
		System.out.println("enter replacement cost: ");
		film.setReplacementCost(sc.nextDouble());
		
		
		
		//TO GET CATEGORY
		category = selectCategory(categories);
		film.setCategory(category);
		
		
		
		//TO GET SPECIAL FEATURES
		System.out.println("enter special features: ");
		film.setSpecialFeatures(sc.next());
		
		
		
		//TO GET AND VALIDATE RATINGS
		do{
			
			System.out.println("enter rating for the film: ");
			ratings = sc.nextInt();
			
			flag = Validate.isValidRating(ratings);
			
			if(!flag)
				System.out.println("enter valid rating!");
			
		}while(!flag);
		
		film.setRatings(ratings);	
		
		
		//TO GET ALL ACTORS
		actors = new ArrayList<>();
		System.out.println("Add all actors");
		do{

			Actor actor = selectActor(allActors);
			
			//to check whether selected actor is already added
			int flag1=0;
			if(!actors.isEmpty()){
				
				for(Actor act : actors){
					if(act.equals(actor)){
						flag1=1;
						break;
					}	
				}
			}
			
			if(flag1!=1)
				actors.add(actor);
			else
				System.out.println("This actor is already added. select another");
			
			
							
			System.out.println("do you want to enter another actor? [y/n]");
			choice = sc.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
						
		film.setActors(actors);
		
		
		
		return film;
	}
	
	
	
	//FUNCTION TO SELECT A LANGUAGE FROM THE LIST
	public Language selectLanguage(List<Language> languages){
		
		Language selectedLanguage=null;
		boolean flag = false;
		
		do{	
			
			//Print Language Details
			System.out.println("\tLANGUAGES");
			for(Language language:languages)
				System.out.println(language.getLanguageId() + "\t" + language.getLanguageName());
			
			System.out.println("Choose Language:");
			int option=sc.nextInt();
			
			//Checking whether a valid language id
			for(Language language: languages)
			{
				if(option==language.getLanguageId())
				{
					flag=true;
					selectedLanguage=language;					
					break;
				}
			}
			
			//Print Error Message for invalid language id
			if(!flag)
				System.out.println("Please select valid Language Id!");
			
		}while(!flag);	
		
		return selectedLanguage;
	}
	
	
	
	//FUNCTION TO SELECT A CATEGORY FROM THE LIST
	public Category selectCategory(List<Category> categories){
		
		Category selectedCategory=null;
		boolean flag = false;
		
		do{	
			
			//Print Category Details
			System.out.println("\tCATEGORIES");
			for(Category category:categories)
				System.out.println(category.getCategoryId() + "\t" + category.getCategoryName());
			
			System.out.println("Choose the Category:");
			int option=sc.nextInt();
			
			//Checking whether a valid language id
			for(Category category:categories)
			{
				if(option==category.getCategoryId())
				{
					flag=true;
					selectedCategory=category;					
					break;
				}
			}
			
			//Print Error Message for invalid category id
			if(!flag)
				System.out.println("Please select valid category Id!");
			
		}while(!flag);	
		
		return selectedCategory;
	}
	
	
	
	//FUNCTION TO SELECT AN ACTOR FROM THE LIST
	public Actor selectActor(List<Actor> allActors){
		
		Actor selectedActor = null;
		boolean flag = false;
		
		do{	
			
			//Print Actor Details
			System.out.println("\tACTORS");
			for(Actor actor: allActors)
				System.out.println(actor.getActorId() + "\t" + actor.getFirstName() + " " + actor.getLastName());
			
			System.out.println("Choose the Actor:");
			int option=sc.nextInt();
			
			//Checking whether the entered Actor Id is valid
			for(Actor actor: allActors)
			{
				if(option==actor.getActorId())
				{
					flag=true;
					selectedActor=actor;					
					break;
				}
			}
			
			//Print Error Message for invalid Actor Id
			if(!flag)
				System.out.println("Please select valid Actor Id!");
			
		}while(!flag);	
		
		
		return selectedActor;
	}
	
	
	
	//TO LIST ALL THE FILMS IN A LIST
	public void getAllFilm(Collection<Film> films){
		
		//getting all the films in the Film repository
		//Collection<Film> films = allFilms.values();
		
		if(films.isEmpty())
			System.out.println("No Film Exists!");
		
		else{
			
			System.out.println("FILM ID"+ "\t" + " TITLE" + "\t" + "DESCRIPTION" +"\t"
				+ "RELEASE_YEAR" + "\t" + "ORIGINAL_LANGUAGE" + "\t" + "OTHER_LANGUAGES" + "\t"
				+ "RENTAL_DURATION"	+ "\t" + "LENGTH" + "\t" + "REPLACEMENT_COST" + "\t"
				+ "RATING" + "\t" + "SPECIAL_FEATURES" + "\t" + "ACTORS" + "\t" + "CATEGORY");
					
					
			for(Film film: films){
						
				printFilm(film);
			}
		}
	}
	
	

	//FUCTION TO PRINT A FILM
	public void printFilm(Film film){
		
		
		if (film!=null) {
			
			String otherLanguages = "";
			String allActors = "";
			//getting the name of all languages in which film is released
			for (Language language : film.getLanguages()) {

				otherLanguages = otherLanguages + language.getLanguageName() + ", ";
			}
			//getting the name of all the actors in the film
			for (Actor actor : film.getActors()) {

				allActors = allActors + actor.getFirstName() + " " + actor.getLastName() + ", ";
			}
			System.out.println("\n" + film.getFilmId() + "\t" + film.getTitle() + "\t" + film.getDescription() + "\t"
					+ film.getReleaseYear() + "\t" + film.getOriginalLanguage().getLanguageName() + "\t"
					+ otherLanguages + "\t" + film.getRentalDuration() + "\t" + film.getLength() + "\t"
					+ film.getReplacementCost() + "\t" + film.getRatings() + "\t" + film.getSpecialFeatures() + "\t"
					+ allActors + "\t" + film.getCategory().getCategoryName());
		}
		
		else
			System.out.println("Film does not exist!");
	
	
	}
}
