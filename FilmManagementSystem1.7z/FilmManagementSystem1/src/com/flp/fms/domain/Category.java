package com.flp.fms.domain;

public class Category {

	
	//private fields category
	private int category_Id;
	private String Category_Name;
	
	
	//No argument constructor for category
	public Category(){}


	// Constructor with fields for category
	public Category(int category_Id, String category_Name) {
		super();
		this.category_Id = category_Id;
		Category_Name = category_Name;
	}


	//Getter and Setter for category
	public int getCategory_Id() {
		return category_Id;
	}


	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}


	public String getCategory_Name() {
		return Category_Name;
	}


	public void setCategory_Name(String category_Name) {
		Category_Name = category_Name;
	}

	// To string for category

	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", Category_Name=" + Category_Name + "]";
	}
	
	
	
	
	
	
	
}
