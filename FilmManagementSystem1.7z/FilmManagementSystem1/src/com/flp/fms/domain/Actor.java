package com.flp.fms.domain;

public class Actor {

	//private fields for actor
	private int actor_Id;
	private String first_Name;
	private String last_Name;
	
	//No argument constructor for actor
	
	public Actor(){}

	
	// Constructor with fields for actor
	public Actor(int actor_Id, String first_Name, String last_Name) {
		super();
		this.actor_Id = actor_Id;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
	}

     //Constructor with fields for actor
	public int getActor_Id() {
		return actor_Id;
	}

     //Getter and Setter for actor
	public String getFirst_Name() {
		return first_Name;
	}


	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}


	public String getLast_Name() {
		return last_Name;
	}


	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}


	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}

	//To string method for actor
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", First_Name=" + first_Name + ", Last_Name=" + first_Name + "]";
	}


	
	
	
	
	
		

	
	
	
	
}
