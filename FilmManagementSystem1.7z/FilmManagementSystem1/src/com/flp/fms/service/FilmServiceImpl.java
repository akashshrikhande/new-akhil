package com.flp.fms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.UserLogin;

public class FilmServiceImpl implements IFilmService{
		
	private IFilmDao filmDao=new FilmDaoImplForList();

	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	
	
	/*public int generate_Film_Id(){
		
		int filmId=0;
		*/
		//Verify filmId has been Duplicated or not
		/*do{
			double fid=Math.random()*1000;
			filmId=(int)fid;
		}while(checkDuplicateFilmId(filmId));
		
		
		return filmId;
	}*/


	/*public boolean checkDuplicateFilmId(int filmId){
		
		Set<Integer> keys= getAllFilms().keyset();
		boolean flag=false;
		if(keys.isEmpty() || keys==null){
			flag= false;
		}else{
			for(Integer key:keys){
				if(key==filmId){
					flag=true;
					break;
				}
			}
		}
		
		return flag;
		
	}
*/
	@Override
	public void addFilm(Film film) {
		filmDao.addFilm(film);
		
	}

	@Override
	public ArrayList<Film> getAllFilms() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}

	@Override
	public Boolean deleteFilm(int filmid) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilm(filmid);
	}

	@Override
	public List<Film> searchFilm(Film film) {
		
		return filmDao.searchFilm(film);
	}

	@Override
	public int updateFilm(int id, Film film) {
		// TODO Auto-generated method stub
		return filmDao.updateFilm(id, film);
	}
	

 
   public Film getFilmByID(int id) {

	return filmDao.getFilmByID(id);
  }


@Override
public boolean isValidUser(UserLogin login) {
	
	return filmDao.isValidUser(login);
}

  }

	/*@Override
	public Map<Integer, Film> searchFilms() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Integer, Film> removeFilm() {
		// TODO Auto-generated method stub
		return null;
	}
	*/