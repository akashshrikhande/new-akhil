package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;


public class ActorDaoImplForList implements IActorDao {
	
	
	@Override
	    public List<Actor> getActorList() {
		
		List<Actor> actor=new ArrayList<>();
		
		/*actors.add(new Actor(101,"Tom","Jerry"));
		actors.add(new Actor(102,"Sharuk","Khan"));
		actors.add(new Actor(103,"Kamal","Hasan"));
		actors.add(new Actor(104,"Salman","Khan"));
		actors.add(new Actor(105,"Rajni","Kant"));
		actors.add(new Actor(106,"Hrithik","Roshan"));
		*/
		
	//	FilmDaoImpForOrgLang filmDao=new FilmDaoImpForOrgLang();
		
		Connection con=getConnection();
		
		String sql="select * from actors";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setFirst_Name(rs.getString(2));
				actor1.setLast_Name(rs.getString(3));
				System.out.println(actor1);
				actor.add(actor1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return actor;
		
		
	}

public static Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		System.out.println("connection established");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/film","root","Pass1234");
			System.out.println("Driver Registered");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}
	
}

	

		
	