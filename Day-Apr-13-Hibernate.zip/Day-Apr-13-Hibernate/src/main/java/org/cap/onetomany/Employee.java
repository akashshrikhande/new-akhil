package org.cap.onetomany;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	@GeneratedValue
	private int empId;
	private String firstName;
	private String salary;
	
	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="companyId_FK")
	private Company company;
	
	public Employee(){}
	
	public Employee( String firstName, String salary, Company company) {
		super();
		this.firstName = firstName;
		this.salary = salary;
		this.company = company;
	}
	

	public Employee(int empId, String firstName, String salary, Company company) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.salary = salary;
		this.company = company;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", salary=" + salary + ", company=" + company
				+ "]";
	}
	
	
	

}
